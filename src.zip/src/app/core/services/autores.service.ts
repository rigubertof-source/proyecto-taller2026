import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Autor } from '../model/autoresModel';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class AutoresService {
   private readonly http = inject(HttpClient);
  private readonly urlApi = `${environment.apiUrl}/autores`;

  getAutores(): Observable<Autor[]> {
    return this.http.get<Autor[]>(this.urlApi);
  }

  buscarPorNombre(bus: string): Observable<Autor[]> {
    return this.http.get<Autor[]>(
      `http://localhost:5155/autoresNom/${encodeURIComponent(bus)}`
    );
  }

  buscarPorEstado(xestado: number): Observable<Autor[]> {
    return this.http.get<Autor[]>(
      `http://localhost:5155/autoresPorEstado/${xestado}`
    );
  }

  getAutorById(coda: number): Observable<Autor> {
    return this.http.get<Autor>(`${this.urlApi}/${coda}`);
  }

  crearAutor(autor: Autor): Observable<string> {
    return this.http.post(this.urlApi, autor, { responseType: 'text' });
  }

  updateAutor(autor: Autor): Observable<string> {
    return this.http.put(this.urlApi, autor, { responseType: 'text' });
  }
}
