import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Tipo } from '../model/tiposModel';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class TiposService {
     private readonly http = inject(HttpClient);
  private urlApi = `${environment.apiUrl}/tipos`;

  getTipos(): Observable<Tipo[]> {
    return this.http.get<Tipo[]>(this.urlApi);
  }

  buscarPorNombre(bus: string): Observable<Tipo[]> {
    return this.http.get<Tipo[]>(`${this.urlApi}Nom/${encodeURIComponent(bus)}`);
  }

  buscarPorEstado(xestado: number): Observable<Tipo[]> {
    return this.http.get<Tipo[]>(`${this.urlApi}PorEstado/${xestado}`);
  }

  getTiposById(code: number): Observable<Tipo> {
    return this.http.get<Tipo>(`${this.urlApi}/${code}`);
  }

  crearTipo(tipo: Tipo): Observable<string> {
    return this.http.post(this.urlApi, tipo, { responseType: 'text' });
  }

  updateTipo(tipo: Tipo): Observable<string> {
    return this.http.put(this.urlApi, tipo, { responseType: 'text' });
  }
}
