import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment.development';
import { DetallePrestamo, EjemplarDisp, Estudiante, Prestamo, PrestamoRequest } from '../model/prestamoModel';

@Injectable({ providedIn: 'root' })
export class PrestamosService {
  private readonly http = inject(HttpClient);
  private readonly urlApi = `${environment.apiUrl}/prestamos`;

  getPrestamos(): Observable<Prestamo[]> { return this.http.get<Prestamo[]>(this.urlApi); }
  getDetalle(codp: number): Observable<DetallePrestamo[]> {
    return this.http.get<DetallePrestamo[]>(`${this.urlApi}/${codp}/detalle`);
  }
  getEstudiantes(): Observable<Estudiante[]> { return this.http.get<Estudiante[]>(`${this.urlApi}/estudiantes`); }
  getEjemplaresDisponibles(): Observable<EjemplarDisp[]> {
    return this.http.get<EjemplarDisp[]>(`${this.urlApi}/ejemplares-disponibles`);
  }
  agregar(req: PrestamoRequest): Observable<string> {
    return this.http.post(this.urlApi, req, { responseType: 'text' });
  }
    eliminar(codp: number): Observable<string> {
    return this.http.delete(`${this.urlApi}/${codp}`, { responseType: 'text' });
  }
}