import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Proceso } from '../model/procesoModel';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class ProcesosService {
  private readonly http = inject(HttpClient);
  private readonly urlApi = `${environment.apiUrl}/procesos`;

  getProcesos(): Observable<Proceso[]> {
    return this.http.get<Proceso[]>(this.urlApi);
  }

  buscarPorNombre(bus: string): Observable<Proceso[]> {
    return this.http.get<Proceso[]>(`${this.urlApi}/nom/${encodeURIComponent(bus)}`);
  }

  buscarPorEstado(xestado: number): Observable<Proceso[]> {
    return this.http.get<Proceso[]>(`${this.urlApi}/estado/${xestado}`);
  }

  getProcesoById(codp: number): Observable<Proceso> {
    return this.http.get<Proceso>(`${this.urlApi}/${codp}`);
  }

  crearProceso(proceso: Proceso): Observable<string> {
    return this.http.post(this.urlApi, proceso, { responseType: 'text' });
  }

  updateProceso(proceso: Proceso): Observable<string> {
    return this.http.put(this.urlApi, proceso, { responseType: 'text' });
  }
}