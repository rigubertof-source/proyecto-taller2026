import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Editorial } from '../model/editorialModel';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class EditorialesService {
    private readonly http = inject(HttpClient);
  private readonly urlApi = `${environment.apiUrl}/editoriales`;

  getEditoriales(): Observable<Editorial[]> {
    return this.http.get<Editorial[]>(this.urlApi);
  }

  buscarPorNombre(bus: string): Observable<Editorial[]> {
    return this.http.get<Editorial[]>(`${this.urlApi}Nom/${encodeURIComponent(bus)}`);
  }

  buscarPorEstado(xestado: number): Observable<Editorial[]> {
    return this.http.get<Editorial[]>(`${this.urlApi}PorEstado/${xestado}`);
  }

  getEditorialById(code: number): Observable<Editorial> {
    return this.http.get<Editorial>(`${this.urlApi}/${code}`);
  }

  crearEditorial(editorial: Editorial): Observable<string> {
    return this.http.post(this.urlApi, editorial, { responseType: 'text' });
  }

  updateEditorial(editorial: Editorial): Observable<string> {
    return this.http.put(this.urlApi, editorial, { responseType: 'text' });
  }
}
