import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment.development';
import { DetalleDevol, DevolPrestamo, DevolucionLista, DevolucionRequest } from '../model/devolucionModel';

@Injectable({ providedIn: 'root' })
export class DevolucionesService {
  private readonly http = inject(HttpClient);
  private readonly urlApi = `${environment.apiUrl}/devoluciones`;

  getPrestamos(): Observable<DevolPrestamo[]> {
    return this.http.get<DevolPrestamo[]>(`${this.urlApi}/prestamos`);
  }
  guardar(req: DevolucionRequest): Observable<string> {
    return this.http.post(this.urlApi, req, { responseType: 'text' });
  }

  getDevoluciones(): Observable<DevolucionLista[]> {
    return this.http.get<DevolucionLista[]>(this.urlApi);
  }
  getDetalleDevolucion(codd: number): Observable<DetalleDevol[]> {
    return this.http.get<DetalleDevol[]>(`${this.urlApi}/${codd}/detalle`);
  }
  anular(codd: number): Observable<string> {
    return this.http.delete(`${this.urlApi}/${codd}`, { responseType: 'text' });
  }
}