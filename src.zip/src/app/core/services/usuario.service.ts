import { inject, Injectable } from '@angular/core';
import { Usuario } from '../model/usuarioModel';
import { Observable, tap } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { MenuService } from './menu.service';

@Injectable({
  providedIn: 'root',
})
export class UsuarioService {
  private readonly http = inject(HttpClient);

  private readonly urlApi = `${environment.apiUrl}/usuarios`;
    private readonly menuService = inject(MenuService);

  getUsuarioPorPersona(codper: number): Observable<Usuario | null> {
    return this.http.get<Usuario | null>(`${this.urlApi}per/${codper}/usuario`);
  }

  guardarUsuario(codper: number, usuario: Usuario): Observable<string> {
    return this.http.put(`${this.urlApi}pers/${codper}/usuario`, usuario, {
      responseType: 'text',
    });
  }
   getUsuarios(): Observable<any[]> {
    return this.http.get<any[]>(this.urlApi);
  }

  asignarRoles(login: string, codigosRoles: number[]): Observable<string> {
    return this.http
      .put(`${this.urlApi}/${login}/roles`, codigosRoles, { responseType: 'text' })
      .pipe(tap(() => this.menuService.notificarCambio()));
  }

}

