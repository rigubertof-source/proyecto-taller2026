import { inject, Injectable } from '@angular/core';
import { AuthService } from '../../features/auth/auth.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Persona } from '../model/personasModel';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class PersonasService {

  private readonly http = inject(HttpClient);
  private readonly urlApi = `${environment.apiUrl}/personas`;

  getPersonas(): Observable<Persona[]> {
    return this.http.get<Persona[]>(this.urlApi);
  }
  buscarPorNombre(bus: string): Observable<Persona[]> {
    return this.http.get<Persona[]>(`${this.urlApi + 'Nom'}/${bus}`);
  }
  buscarPorEstado(xestado: number): Observable<Persona[]> {
    return this.http.get<Persona[]>(`${this.urlApi + 'PorEstado'}/${xestado}`);
  }
  buscarPorTipo(xtipo: string): Observable<Persona[]> {
    return this.http.get<Persona[]>(`${this.urlApi + 'PorTipo'}/${xtipo}`);
  }
  getPersonaById(codper: number): Observable<Persona> {
    return this.http.get<Persona>(`${this.urlApi}/${codper}`);
  }
  codperConUsuario(): Observable<number[]> {
  return this.http.get<number[]>(`${this.urlApi}ConUsuario`);
}
  crearPersona(persona: Persona): Observable<Persona> {
    return this.http.post<Persona>(this.urlApi, persona);
  }
  updatePersona(persona: Persona): Observable<Persona> {
    return this.http.put<Persona>(`${this.urlApi}/${persona.codper}`, persona);
  }
  subirFoto(codper: number, archivo: File): Observable<Persona> {
    const fd = new FormData();
    fd.append('file', archivo);
    return this.http.post<Persona>(`${this.urlApi}/${codper}/foto`, fd);
  }
}

