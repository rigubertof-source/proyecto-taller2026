import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { Observable } from 'rxjs';
import { Texto } from '../model/textosModel';

@Injectable({
  providedIn: 'root',
})
export class TextosService {
  private readonly http = inject(HttpClient);
  private urlApi = `${environment.apiUrl}/textos`;


  getTextos(): Observable<Texto[]> {
    return this.http.get<Texto[]>(this.urlApi);
  }
  getAutores(): Observable<any[]> {
    return this.http.get<any[]>(this.urlApi);
  }
  buscarPorTituloOAutor(bus: string): Observable<Texto[]> {
    return this.http.get<Texto[]>(`${this.urlApi}Filtro/${encodeURIComponent(bus)}`);
  }
  buscarPorTipo(codtipo: number): Observable<Texto[]> {
    return this.http.get<Texto[]>(`${this.urlApi}PorTipo/${codtipo}`);
  }
  getTextoById(code: number): Observable<Texto> {
    return this.http.get<Texto>(`${this.urlApi}/${code}`);
  }

  buscarPorIsbn(isbn: string): Observable<Texto> {
    return this.http.get<Texto>(
      `${this.urlApi}Isbn/${encodeURIComponent(isbn)}`
    );
  }

  buscarPorArea(coda: number): Observable<Texto[]> {
    return this.http.get<Texto[]>(`${this.urlApi}PorArea/${coda}`);
  }

  buscarPorEditorial(code: number): Observable<Texto[]> {
    return this.http.get<Texto[]>(`${this.urlApi}PorEditorial/${code}`);
  }

  buscarPorFechas(fechaIni: string, fechaFin: string): Observable<Texto[]> {
    const params = new HttpParams()
      .set('fechaIni', fechaIni)
      .set('fechaFin', fechaFin);
    return this.http.get<Texto[]>(`${this.urlApi}PorFechas`, { params });
  }


  crearTexto(texto: Texto): Observable<string> {
    return this.http.post(this.urlApi, texto, { responseType: 'text' });
  }

  updateTexto(texto: Texto): Observable<string> {
    return this.http.put(this.urlApi, texto, { responseType: 'text' });
  }

  darBaja(codt: number): Observable<string> {
    return this.http.put(`${this.urlApi}/${codt}/baja`, null, { responseType: 'text' });
  }

  habilitar(codt: number): Observable<string> {
    return this.http.put(`${this.urlApi}/${codt}/habilitar`, null, { responseType: 'text' });
  }
}
