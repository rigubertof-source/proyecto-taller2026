import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment.development';
import { Ejemplar } from '../model/ejemplarModel';

@Injectable({ providedIn: 'root' })
export class EjemplaresService {
  private readonly http = inject(HttpClient);
  private readonly urlApi = `${environment.apiUrl}/ejemplares`;

  getPorTexto(codt: number): Observable<Ejemplar[]> {
    return this.http.get<Ejemplar[]>(`${this.urlApi}/texto/${codt}`);
  }

  agregar(codt: number, codinv: number, login: string): Observable<string> {
  return this.http.post(
    `${this.urlApi}/texto/${codt}?codinv=${codinv}&login=${encodeURIComponent(login)}`,
    null, { responseType: 'text' });
}

cambiarCodinv(actual: number, nuevo: number): Observable<string> {
  return this.http.put(`${this.urlApi}/${actual}/codinv?nuevo=${nuevo}`, null, { responseType: 'text' });
}

  darBaja(codinv: number, login: string): Observable<string> {
    return this.http.put(`${this.urlApi}/${codinv}/baja?login=${encodeURIComponent(login)}`, null, { responseType: 'text' });
  }

  darAlta(codinv: number): Observable<string> {
    return this.http.put(`${this.urlApi}/${codinv}/alta`, null, { responseType: 'text' });
  }

  cambiarDisponible(codinv: number): Observable<string> {
    return this.http.put(`${this.urlApi}/${codinv}/disponible`, null, { responseType: 'text' });
  }
  getTextosActivos(): Observable<number[]> {
  return this.http.get<number[]>(`${this.urlApi}/textos-activos`);
}
getPdf(codt: number): Observable<Blob> {
  return this.http.get(`${this.urlApi}/pdf/${codt}`, { responseType: 'blob' });
}
}