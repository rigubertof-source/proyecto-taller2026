import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { Roles } from '../model/usuarioModel';
import { environment } from '../../../environments/environment';
import { Rol } from '../model/rolesModel';
import { MenuService } from './menu.service';
@Injectable({
  providedIn: 'root',
})
export class RolesService {
   private readonly http = inject(HttpClient);
  private urlApi = `${environment.apiUrl}/roles`;
private menusService = inject(MenuService);
  private rolesSubject = new BehaviorSubject<Roles[]>([]);
  private rolActualSubject = new BehaviorSubject<Roles | null>(null);

  roles$ = this.rolesSubject.asObservable();
  rolActual$ = this.rolActualSubject.asObservable();

  cargarRoles(): Observable<Roles[]> {
    return this.http.get<Roles[]>(`${this.urlApi}persona`).pipe(
      tap((roles) => {
        this.rolesSubject.next(roles);
        const guardado = Number(localStorage.getItem('codr'));
        const defecto = roles.find((r) => r.codr === guardado) ?? roles[0] ?? null;
        this.rolActualSubject.next(defecto);
      })
    );
  }

  seleccionar(codr: number): void {
    const rol = this.rolesSubject.value.find((r) => r.codr === codr);
    if (rol) {
      localStorage.setItem('codr', String(codr));
      this.rolActualSubject.next(rol);
    }
  }

  limpiar(): void {
    localStorage.removeItem('codr');
    this.rolesSubject.next([]);
    this.rolActualSubject.next(null);
  }
  getRoles(): Observable<Rol[]> {
    return this.http.get<Rol[]>(this.urlApi);
  }

  buscarPorNombre(bus: string): Observable<Rol[]> {
    return this.http.get<Rol[]>(`${this.urlApi}Nom/${encodeURIComponent(bus)}`);
  }

  buscarPorEstado(xestado: number): Observable<Rol[]> {
    return this.http.get<Rol[]>(`${this.urlApi}PorEstado/${xestado}`);
  }

  getRolById(code: number): Observable<Rol> {
    return this.http.get<Rol>(`${this.urlApi}/${code}`);
  }

  crearRol(rol: Rol): Observable<string> {
    return this.http.post(this.urlApi, rol, { responseType: 'text' });
  }

  updateRol(rol: Rol): Observable<string> {
    return this.http.put(this.urlApi, rol, { responseType: 'text' });
  }
  asignarMenus(codr: number, codigosMenus: number[]): Observable<string> {
  return this.http
    .put(`${this.urlApi}/${codr}/menus`, codigosMenus, { responseType: 'text' })
    .pipe(tap(() => this.menusService.notificarCambio())); 
}
}
