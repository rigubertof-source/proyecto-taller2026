import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Area } from '../model/areasModel';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AreasService {
  private readonly http = inject(HttpClient);
  private readonly urlApi = `${environment.apiUrl}/areas`;

  getAreas(): Observable<Area[]> {
    return this.http.get<Area[]>(this.urlApi);
  }

  buscarPorNombre(bus: string): Observable<Area[]> {
    return this.http.get<Area[]>(
      `${this.urlApi}Nom/${encodeURIComponent(bus)}`
    );
  }

  buscarPorEstado(xestado: number): Observable<Area[]> {
    return this.http.get<Area[]>(
      `${this.urlApi}PorEstado/${xestado}`
    );
  }

  getAreaById(coda: number): Observable<Area> {
    return this.http.get<Area>(`${this.urlApi}/${coda}`);
  }

  crearArea(area: Area): Observable<string> {
    return this.http.post(this.urlApi, area, {
      responseType: 'text'
    });
  }
  cambiarEstadoArea(coda: number, nuevoEstado: number): Observable<string> {
    return this.http.patch(`${this.urlApi}/${coda}/estado/${nuevoEstado}`, null, {
      responseType: 'text'
    });
  }
  updateArea(area: Area): Observable<string> {
    return this.http.put(this.urlApi, area, {
      responseType: 'text'
    });
  }
}
