import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Menu, Menusi } from '../model/menusModel';
import { Observable, Subject } from 'rxjs';
import { environment } from '../../../environments/environment.development';
import { Component, HostListener, OnInit} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Injectable({
  providedIn: 'root',
})
export class MenuService {
  private readonly http = inject(HttpClient);
  private readonly urlApi = `${environment.apiUrl}/menus`;

  private readonly _menuActualizado = new Subject<void>();
  readonly menuActualizado$ = this._menuActualizado.asObservable();

  notificarCambio(): void {
    this._menuActualizado.next();
  }
  getMenu(): Observable<Menusi[]> {
    return this.http.get<Menusi[]>(this.urlApi);
  }

  getMenuById(codm: number): Observable<Menusi> {
    return this.http.get<Menusi>(`${this.urlApi}/${codm}`);
  }
   getMenuByRol(codr: number): Observable<Menusi[]> {
    return this.http.get<Menusi[]>(`${this.urlApi}/rol/${codr}`);
  }
  getMenus(): Observable<Menu[]> {
    return this.http.get<Menu[]>(this.urlApi);
  }

  buscarPorNombre(bus: string): Observable<Menu[]> {
    return this.http.get<Menu[]>(`${this.urlApi}Nom/${encodeURIComponent(bus)}`);
  }

  buscarPorEstado(xestado: number): Observable<Menu[]> {
    return this.http.get<Menu[]>(`${this.urlApi}PorEstado/${xestado}`);
  }
  crearMenu(menu: Menu): Observable<string> {
    return this.http.post(this.urlApi, menu, { responseType: 'text' });
  }
  updateMenu(menu: Menu): Observable<string> {
    return this.http.put(this.urlApi, menu, { responseType: 'text' });
  }
asignarProcesos(codm: number, codigosProcesos: number[]): Observable<string> {
  return this.http.put(`${this.urlApi}/${codm}/procesos`, codigosProcesos, { responseType: 'text' });
}

}
