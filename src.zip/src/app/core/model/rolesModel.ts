export interface Rol {
  code: number;
  nombre: string;
  estado: number;
}