export interface Prestamo {
  codp: number; fecha: string; fini: string; ffin: string;
  tipopres: number; estado: number; ci: number;
  nombre: string; ap: string; am: string | null;
}
export interface DetallePrestamo { codinv: number; titulo: string; estado: number; }
export interface Estudiante { ci: number; nombre: string; ap: string; am: string | null; }
export interface EjemplarDisp { codinv: number; titulo: string; }
export interface PrestamoRequest {
  fecha: string; fini: string; ffin: string; tipopres: number;
  ci: number; codinvs: number[]; login: string;
}