export interface Tipo {
  codtipo?: number;
  nombre: string;
  estado: number;
  sw: number;
}