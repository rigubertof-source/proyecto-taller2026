export interface Ejemplar {
  codinv: number;
  estado: number;      
  disponible: number;   
}