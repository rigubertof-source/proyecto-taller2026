export interface Usuario {
  login: string;
  passwd: string;
  estado: number;
  codper?:number;
  persona?: any;
  roles?: Roles[];
}
export interface Roles {
  codr: number;
  nombre: string;
}