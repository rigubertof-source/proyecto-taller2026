export interface Datos {
  ci: string;
}
export interface Telefono {
  id: {
    codper: number;
    numero: string;
  };
}
export interface Persona {
  codper?: number;
  nombre: string;
  ap?: string;
  am?: string;
  genero: string;
  estado: number;
  tipoper: string;
  foto?: string;
  datos?: Datos | null;
  telefonos?: Telefono[];
}