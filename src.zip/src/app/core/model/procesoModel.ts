export interface Proceso {
  codp?: number; 
  nombre: string;
  enlace: string; 
  estado: number;
  asignado?: boolean;
}