export interface Proceso {
  codp: number;
  nombre: string;
  enlace:string;
  estado: number;
}
export interface Menusi {
  codm: number;
  nombre: string;
  estado: number;
  procesos:Proceso[];
}
export interface Menu {
  codm: number;
  nombre: string;
  estado: number;
}
