export interface Editorial {
  code?: number;
  nombre: string;
  estado: number;
}