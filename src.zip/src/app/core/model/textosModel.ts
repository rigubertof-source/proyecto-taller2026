// src/app/model/textosModel.ts

export interface Area {
  coda: number;
  nombre?: string;
}

export interface Editorial {
  code: number;
  nombre?: string;
}

export interface Autor {
  codau: number;
  nombre?: string;
  apellido?: string;
}

export interface Tipo {
  codtipo: number;
  nombre: string;
  estado?: number;
  sw?: number;
}

export interface Texto {
  codt: number;
  titulo: string;
  resumen?: string | null;
  isbn?: string | null;
  edicion?: number;
  fechapub?: string;
  estado?: number;
  area?: { coda: number; nombre: string };
  editorial?: { code: number; nombre: string };
  tipos?: { codtipo: number; nombre: string }[];
  autores?: { coda: number; nombre: string; ap?: string; am?: string }[];
}