import { Persona } from '../model/personasModel';
import { urlFoto } from './urlFoto';

const esc = (v: unknown): string =>
  String(v ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));

export function fichaPersonaHtml(p: Persona): string {
  const foto = new URL(urlFoto(p.foto), document.baseURI).href;
  const telefonos =
    (p.telefonos ?? []).map(t => `<div>${esc(t.id.numero)}</div>`).join('') || '—';
  const genero = p.genero === 'M' ? 'Masculino' : p.genero === 'F' ? 'Femenino' : '—';

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ficha de Persona</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 30px; color: #000; }
    h2 { text-align: center; margin-bottom: 20px; }
    .foto { display: block; margin: 0 auto 20px; width: 140px; height: 140px;
            object-fit: cover; border-radius: 50%; border: 2px solid #999; }
    table { margin: 0 auto; border-collapse: collapse; }
    th { text-align: right; padding: 6px 12px; vertical-align: top; }
    td { padding: 6px 12px; }
  </style>
</head>
<body>
  <h2>Datos de la Persona</h2>
  <img class="foto" src="${foto}" alt="Foto">
  <table>
    <tr><th>Nombre:</th><td>${esc(p.nombre)} ${esc(p.ap)} ${esc(p.am)}</td></tr>
    <tr><th>Cédula:</th><td>${esc(p.datos?.ci) || '—'}</td></tr>
    <tr><th>Tipo:</th><td>${p.tipoper === 'A' ? 'Administrativo' : 'Público'}</td></tr>
    <tr><th>Estado:</th><td>${p.estado === 1 ? 'Activo' : 'Baja'}</td></tr>
    <tr><th>Género:</th><td>${genero}</td></tr>
    <tr><th>Teléfonos:</th><td>${telefonos}</td></tr>
  </table>
</body>
</html>`;
}