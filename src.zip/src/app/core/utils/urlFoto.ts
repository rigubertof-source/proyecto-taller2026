export function urlFoto(foto?: string | null): string {
  if (!foto) return 'user.png'; // Imagen por defecto

  // Si ya es una URL completa o una vista previa local, la dejamos pasar
  if (foto.startsWith('http') || foto.startsWith('blob:')) {
    return foto;
  }

  // 👇 Aquí atrapamos el nombre "persona_1_2f8...jpg" y le ponemos el /fotos/
  const backendUrl = 'http://localhost:5155';
  const rutaLimpia = foto.startsWith('/fotos/') ? foto : `/fotos/${foto}`;

  return `${backendUrl}${rutaLimpia}`;
}