import { Autor } from '../model/autoresModel';
import { urlFoto } from './urlFoto'; // opcional, si el autor tuviera foto

export function fichaAutor(a: Autor): string {
  const genero = a.genero === 'M' ? 'Masculino'
               : a.genero === 'F' ? 'Femenino'
               : '—';

  const estado = a.estado === 1 ? 'Activo' : 'Baja';

  return `
    <html>
      <head>
        <meta charset="utf-8" />
        <title>Ficha de Autor</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 24px; }
          h1 { font-size: 20px; margin-bottom: 4px; }
          .sub { color: #666; margin-bottom: 16px; }
          table { width: 100%; border-collapse: collapse; }
          th, td { padding: 8px 10px; border-bottom: 1px solid #ddd; text-align: left; }
          th { width: 35%; color: #444; }
        </style>
      </head>
      <body>
        <h1>Ficha de Autor</h1>
        <div class="sub">Código: ${a.coda ?? '—'}</div>
        <table>
          <tr><th>Nombre</th><td>${a.nombre ?? '—'}</td></tr>
          <tr><th>Apellido Paterno</th><td>${a.ap ?? '—'}</td></tr>
          <tr><th>Apellido Materno</th><td>${a.am || '—'}</td></tr>
          <tr><th>Género</th><td>${genero}</td></tr>
          <tr><th>Estado</th><td>${estado}</td></tr>
        </table>
      </body>
    </html>
  `;
}